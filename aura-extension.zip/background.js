chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "voice-command" || typeof message.text !== "string") {
    return false;
  }

  handleCommand(message.text, Array.isArray(message.history) ? message.history : [])
    .then((response) => sendResponse(response))
    .catch((error) => {
      console.error("AURA command failed:", error);
      sendResponse({ text: `I couldn't complete that request: ${error.message}` });
    });

  return true;
});

async function handleCommand(rawText, history) {
  const text = rawText.trim();
  const normalized = text.toLowerCase();
  if (!text) return { text: "I didn't catch that. Say it again when you're ready." };

  if (/^(what |which )?(tabs|pages) (are )?(open|opened)|^list (my )?(tabs|open tabs)/.test(normalized)) {
    return { text: await describeTabs() };
  }

  const switchMatch = normalized.match(/^(?:switch to|go to|activate) (?:the )?(.+?)(?: tab)?$/);
  if (switchMatch) {
    return { text: await activateTab(switchMatch[1]) };
  }

  const closeMatch = normalized.match(/^close (?:the )?(.+?) tab$/);
  if (closeMatch && !["current", "this", "active"].includes(closeMatch[1])) {
    return { text: await closeNamedTab(closeMatch[1]) };
  }
  if (/^(close|close this|close current|close this tab|close current tab)$/.test(normalized)) {
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!activeTab?.id) return { text: "I couldn't find the current tab." };
    await chrome.tabs.remove(activeTab.id);
    return { text: "Closed the current tab." };
  }

  const searchMatch = text.match(/^(?:search(?: google)? for|google) (.+)$/i);
  if (searchMatch) {
    const query = searchMatch[1].trim();
    await chrome.tabs.create({
      url: `https://www.google.com/search?q=${encodeURIComponent(query)}`
    });
    return { text: `Opened a Google search for ${query} in a new tab. Your current tab is still open.` };
  }

  const openMatch = text.match(/^open (.+)$/i);
  if (openMatch) {
    const target = openMatch[1].trim();
    const url = normalizeWebUrl(target);
    if (url) {
      await chrome.tabs.create({ url });
      return { text: `Opened ${target} in a new tab.` };
    }
    await chrome.tabs.create({
      url: `https://www.google.com/search?q=${encodeURIComponent(target)}`
    });
    return { text: `I couldn't identify a website for ${target}, so I searched for it in a new tab.` };
  }

  const localReply = answerConversationally(normalized, history);
  if (localReply) return { text: localReply };

  if (isKnowledgeQuestion(normalized)) {
    return { text: await answerQuestion(text, history) };
  }
  return {
    text: `I hear you. I can keep talking with you, help with browser tabs, or look up factual questions. What would you like to explore about “${text}”?`
  };
}

function answerConversationally(text, history) {
  if (/^(hi|hello|hey|good morning|good afternoon|good evening)\b/.test(text)) {
    return "Hello. I'm here with you. What would you like to talk about?";
  }
  if (/^(who are you|what are you|are you (an? )?(ai|artificial intelligence))\b/.test(text)) {
    return "I'm AURA, a lightweight assistant built into this extension. I can chat using my own simple conversation rules, look up public information, and manage your Chrome tabs. I don't use a hosted AI model, and I don't learn or reason like a large language model.";
  }
  if (/^(how are you|how's it going|how are things)\b/.test(text)) {
    return "I'm running smoothly and ready to help. How are things with you?";
  }
  if (/^(thank you|thanks|cheers)\b/.test(text)) {
    return "You're welcome. What else can I help you with?";
  }
  if (/^(goodbye|bye|see you|that's all)\b/.test(text)) {
    return "Until next time. I'll be here when you need me.";
  }
  if (/^(help|what can you help me with|what can you do)\b/.test(text)) {
    return "You can ask me to list, switch, or close Chrome tabs; open a website; search Google in a new tab; ask for public facts from Wikipedia and DuckDuckGo; or just chat with me.";
  }
  if (/^(what time is it|tell me the time)\b/.test(text)) {
    return `It's ${new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date())}.`;
  }
  if (/^(what('s| is) the date|what day is it|tell me the date)\b/.test(text)) {
    return `Today is ${new Intl.DateTimeFormat(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" }).format(new Date())}.`;
  }

  const calculation = text.match(/^(?:calculate|what is|what's)\s+([0-9().+\-*/%\s]+)\??$/);
  if (calculation) {
    const result = calculate(calculation[1]);
    return result === null
      ? "I couldn't parse that calculation. I can work out basic arithmetic with parentheses."
      : `That comes to ${result}.`;
  }

  if (/^(tell me more|explain that|what about that|can you elaborate)\b/.test(text)) {
    const previousQuestion = [...history].reverse().find((turn) => turn.role === "user" && turn.text !== text);
    if (previousQuestion) return null;
    return "Sure. What would you like me to explain in more detail?";
  }
  return null;
}

function isKnowledgeQuestion(text) {
  return /^(tell me about|explain|define|who|what|where|when|why|how|which|is|are|does|do|can|could|would|should)\b/.test(text) ||
    /^(tell me more|explain that|what about that|can you elaborate)\b/.test(text) ||
    text.endsWith("?");
}

function calculate(expression) {
  if (expression.length > 100) return null;
  let index = 0;

  function skipSpaces() {
    while (expression[index] === " ") index += 1;
  }
  function parseNumber() {
    skipSpaces();
    if (expression[index] === "(") {
      index += 1;
      const value = parseExpression();
      skipSpaces();
      if (expression[index] !== ")") throw new Error("Missing closing parenthesis");
      index += 1;
      return value;
    }
    const start = index;
    while (/[0-9.]/.test(expression[index] || "")) index += 1;
    if (start === index) throw new Error("Expected a number");
    const value = Number(expression.slice(start, index));
    if (!Number.isFinite(value)) throw new Error("Invalid number");
    return value;
  }
  function parseFactor() {
    skipSpaces();
    if (expression[index] === "+" || expression[index] === "-") {
      const sign = expression[index++] === "-" ? -1 : 1;
      return sign * parseFactor();
    }
    let value = parseNumber();
    while (true) {
      skipSpaces();
      const operator = expression[index];
      if (operator !== "*" && operator !== "/" && operator !== "%") break;
      index += 1;
      const right = parseFactor();
      if ((operator === "/" || operator === "%") && right === 0) throw new Error("Division by zero");
      if (operator === "*") value *= right;
      if (operator === "/") value /= right;
      if (operator === "%") value %= right;
    }
    return value;
  }
  function parseExpression() {
    let value = parseFactor();
    while (true) {
      skipSpaces();
      const operator = expression[index];
      if (operator !== "+" && operator !== "-") break;
      index += 1;
      const right = parseFactor();
      value = operator === "+" ? value + right : value - right;
    }
    return value;
  }

  try {
    const value = parseExpression();
    skipSpaces();
    return index === expression.length && Number.isFinite(value) ? Number(value.toPrecision(12)) : null;
  } catch {
    return null;
  }
}

function normalizeWebUrl(target) {
  const candidate = /^https?:\/\//i.test(target) ? target : `https://${target}`;
  try {
    const url = new URL(candidate);
    if (!url.hostname.includes(".") || !["http:", "https:"].includes(url.protocol)) {
      return null;
    }
    return url.href;
  } catch {
    return null;
  }
}

async function describeTabs() {
  const tabs = await chrome.tabs.query({});
  if (tabs.length === 0) return "There are no open tabs.";
  const names = tabs.map((tab, index) =>
    `${index + 1}: ${tab.title || tab.url || "Untitled"}${tab.active ? " (active)" : ""}`
  );
  return `You have ${tabs.length} tabs open. ${names.join(". ")}.`;
}

async function activateTab(query) {
  const tabs = await chrome.tabs.query({});
  const match = tabs.find((tab) =>
    (tab.title || "").toLowerCase().includes(query) ||
    (tab.url || "").toLowerCase().includes(query)
  );
  if (!match?.id) return `I couldn't find an open tab matching ${query}.`;
  if (match.windowId !== undefined) {
    await chrome.windows.update(match.windowId, { focused: true });
  }
  await chrome.tabs.update(match.id, { active: true });
  return `Switched to ${match.title || "that tab"}.`;
}

async function closeNamedTab(query) {
  const tabs = await chrome.tabs.query({});
  const match = tabs.find((tab) =>
    (tab.title || "").toLowerCase().includes(query) ||
    (tab.url || "").toLowerCase().includes(query)
  );
  if (!match?.id) return `I couldn't find an open tab matching ${query}.`;
  await chrome.tabs.remove(match.id);
  return `Closed ${match.title || "that tab"}.`;
}

async function answerQuestion(question, history) {
  let searchText = question;
  if (/^(tell me more|explain that|what about that|can you elaborate)\b/i.test(question)) {
    const previousQuestion = [...history].reverse().find((turn) =>
      turn.role === "user" && turn.text.toLowerCase() !== question.toLowerCase()
    );
    if (previousQuestion) searchText = previousQuestion.text;
  }

  const [wikipedia, duckDuckGo] = await Promise.allSettled([
    searchWikipedia(searchText),
    searchDuckDuckGo(searchText)
  ]);
  const parts = [];
  if (wikipedia.status === "fulfilled" && wikipedia.value) parts.push(wikipedia.value);
  if (duckDuckGo.status === "fulfilled" && duckDuckGo.value) parts.push(duckDuckGo.value);
  const failures = [wikipedia, duckDuckGo]
    .filter((result) => result.status === "rejected")
    .map((result) => result.reason?.message || "unknown network error");

  if (parts.length === 0) {
    if (failures.length > 0) {
      throw new Error(`Knowledge sources are unavailable: ${failures.join("; ")}`);
    }
    return "I couldn't find a concise answer in Wikipedia or DuckDuckGo for that question. You can say “search for” and your topic to open Google in a new tab.";
  }
  const answer = searchText !== question ? `${parts.join(" ")} I looked that up in response to your earlier question.` : parts.join(" ");
  const sourceNotice = failures.length
    ? ` One knowledge source could not be reached: ${failures.join("; ")}.`
    : "";
  return `${answer} These are quick summaries from live sources; check the original pages for detail.${sourceNotice}`;
}

async function searchWikipedia(question) {
  const params = new URLSearchParams({
    action: "query",
    generator: "search",
    gsrsearch: question,
    gsrlimit: "3",
    prop: "extracts",
    exintro: "1",
    explaintext: "1",
    exchars: "650",
    format: "json",
    origin: "*"
  });
  const response = await fetch(`https://en.wikipedia.org/w/api.php?${params}`);
  if (!response.ok) throw new Error(`Wikipedia returned ${response.status}`);
  const data = await response.json();
  const pages = Object.values(data.query?.pages || {});
  const summaries = pages
    .filter((page) => page.extract)
    .slice(0, 2)
    .map((page) => `${page.title}: ${page.extract} (source: https://en.wikipedia.org/wiki/${encodeURIComponent(page.title.replaceAll(" ", "_"))})`);
  return summaries.length ? `Wikipedia: ${summaries.join(" ")}` : "";
}

async function searchDuckDuckGo(question) {
  const params = new URLSearchParams({
    q: question,
    format: "json",
    no_html: "1",
    skip_disambig: "1"
  });
  const response = await fetch(`https://api.duckduckgo.com/?${params}`);
  if (!response.ok) throw new Error(`DuckDuckGo returned ${response.status}`);
  const data = await response.json();
  const text = [data.Answer, data.AbstractText, ...extractRelatedTopics(data.RelatedTopics)]
    .filter((item) => typeof item === "string" && item.trim())
    .slice(0, 2)
    .join(" ");
  return text ? `DuckDuckGo: ${text}${data.AbstractURL ? ` (source: ${data.AbstractURL})` : ""}` : "";
}

function extractRelatedTopics(topics) {
  if (!Array.isArray(topics)) return [];
  return topics.flatMap((topic) => {
    if (typeof topic.Text === "string") return [topic.Text];
    return extractRelatedTopics(topic.Topics);
  });
}
