const canvas = document.querySelector("#orb");
const context = canvas.getContext("2d");
const statusLine = document.querySelector("#status");
const systemState = document.querySelector("#system-state");
const transcriptLine = document.querySelector("#transcript");
const answerLine = document.querySelector("#answer");
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const conversation = [];

const particles = Array.from({ length: 520 }, (_, index, all) => {
  const y = 1 - (index / (all.length - 1)) * 2;
  const radius = Math.sqrt(1 - y * y);
  const angle = Math.PI * (3 - Math.sqrt(5)) * index;
  return {
    x: Math.cos(angle) * radius,
    y,
    z: Math.sin(angle) * radius,
    phase: Math.random() * Math.PI * 2,
    size: 0.45 + Math.random() * 1.25
  };
});

let width = 0;
let height = 0;
let yaw = 0;
let pitch = 0.15;
let zoom = 1;
let spread = 1;
let pointerStart = null;
let dragged = false;
let recognition;
let listening = false;
let recognitionError = false;
let responding = false;

function resizeCanvas() {
  const bounds = canvas.getBoundingClientRect();
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  width = bounds.width;
  height = bounds.height;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
}

function renderOrb(time) {
  context.clearRect(0, 0, width, height);
  if (!width || !height) return requestAnimationFrame(renderOrb);

  const radius = Math.min(width, height) * 0.39 * zoom;
  const centerX = width / 2;
  const centerY = height / 2;
  const cosYaw = Math.cos(yaw);
  const sinYaw = Math.sin(yaw);
  const cosPitch = Math.cos(pitch);
  const sinPitch = Math.sin(pitch);
  const projected = particles.map((particle) => {
    const spreadScale = spread * (1 + Math.sin(time * 0.0006 + particle.phase) * 0.012);
    const x = particle.x * spreadScale;
    const y = particle.y * spreadScale;
    const z = particle.z * spreadScale;
    const rotatedX = x * cosYaw - z * sinYaw;
    const rotatedZ = x * sinYaw + z * cosYaw;
    const rotatedY = y * cosPitch - rotatedZ * sinPitch;
    const depth = y * sinPitch + rotatedZ * cosPitch;
    const perspective = 1.35 / (1.35 - depth * 0.24);
    return {
      x: centerX + rotatedX * radius * perspective,
      y: centerY + rotatedY * radius * perspective,
      z: depth,
      size: particle.size * perspective,
      alpha: 0.2 + ((depth + 1) / 2) * 0.75
    };
  });

  const glow = context.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius * 1.25);
  glow.addColorStop(0, listening ? "rgba(5, 142, 184, 0.15)" : "rgba(5, 111, 151, 0.12)");
  glow.addColorStop(1, "rgba(5, 30, 46, 0)");
  context.fillStyle = glow;
  context.fillRect(0, 0, width, height);

  const linkDistance = Math.max(9, radius * 0.105);
  for (let index = 0; index < projected.length; index += 1) {
    const point = projected[index];
    for (let next = index + 1; next < projected.length; next += 1) {
      const other = projected[next];
      const dx = point.x - other.x;
      const dy = point.y - other.y;
      const distance = Math.hypot(dx, dy);
      if (distance < linkDistance && Math.abs(point.z - other.z) < 0.33) {
        context.strokeStyle = `rgba(37, 197, 233, ${0.12 * (1 - distance / linkDistance)})`;
        context.lineWidth = 0.55;
        context.beginPath();
        context.moveTo(point.x, point.y);
        context.lineTo(other.x, other.y);
        context.stroke();
      }
    }
  }

  for (const point of projected) {
    context.beginPath();
    context.arc(point.x, point.y, Math.max(0.55, point.size), 0, Math.PI * 2);
    context.fillStyle = `rgba(${Math.round(92 + point.alpha * 85)}, ${Math.round(190 + point.alpha * 60)}, 255, ${point.alpha})`;
    context.shadowColor = "#23d9ff";
    context.shadowBlur = point.z > 0 ? 8 : 3;
    context.fill();
  }
  context.shadowBlur = 0;
  if (!dragged && !listening) yaw += 0.0011;
  requestAnimationFrame(renderOrb);
}

function adjustOrb(event) {
  if (!event.cancelable) return;
  event.preventDefault();
  const direction = Math.sign(event.deltaY);
  zoom = Math.min(1.55, Math.max(0.62, zoom - direction * 0.055));
  spread = Math.min(1.75, Math.max(0.66, spread - direction * 0.07));
}

canvas.addEventListener("wheel", adjustOrb, { passive: false });
canvas.addEventListener("pointerdown", (event) => {
  pointerStart = { x: event.clientX, y: event.clientY };
  dragged = false;
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener("pointermove", (event) => {
  if (!pointerStart) return;
  const dx = event.clientX - pointerStart.x;
  const dy = event.clientY - pointerStart.y;
  if (Math.abs(dx) + Math.abs(dy) > 3) dragged = true;
  if (dragged) {
    yaw += dx * 0.008;
    pitch = Math.max(-1.2, Math.min(1.2, pitch + dy * 0.008));
    pointerStart = { x: event.clientX, y: event.clientY };
  }
});
canvas.addEventListener("pointerup", () => {
  if (!dragged) toggleListening();
  pointerStart = null;
  window.setTimeout(() => { dragged = false; }, 0);
});
canvas.addEventListener("pointercancel", () => {
  pointerStart = null;
  dragged = false;
});
canvas.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    toggleListening();
  }
});

window.addEventListener("resize", resizeCanvas);
resizeCanvas();
requestAnimationFrame(renderOrb);

if (!SpeechRecognition) {
  systemState.textContent = "VOICE UNAVAILABLE";
  statusLine.textContent = "THIS BROWSER DOES NOT SUPPORT VOICE INPUT";
  answerLine.textContent = "Try Chrome to use the built-in speech recognition. You can still rotate and reshape the orb.";
} else {
  recognition = new SpeechRecognition();
  recognition.lang = navigator.language || "en-US";
  recognition.continuous = true;
  recognition.interimResults = false;

  recognition.onstart = () => setListening(true);
  recognition.onresult = (event) => {
    const result = event.results[event.results.length - 1];
    if (result.isFinal && result[0].transcript.trim()) {
      processVoiceInput(result[0].transcript.trim());
    }
  };
  recognition.onerror = (event) => {
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      recognitionError = true;
      setListening(false);
      systemState.textContent = "MICROPHONE PERMISSION";
      statusLine.textContent = "MICROPHONE ACCESS IS BLOCKED";
      answerLine.textContent = "Allow microphone access for this extension in Chrome, then tap the orb to try again.";
    } else if (event.error !== "no-speech" && event.error !== "aborted") {
      recognitionError = true;
      setListening(false);
      systemState.textContent = "VOICE ERROR";
      statusLine.textContent = "VOICE INPUT STOPPED";
      answerLine.textContent = `Speech recognition stopped: ${event.error}.`;
    }
  };
  recognition.onend = () => {
    if (listening && !recognitionError && !responding) {
      try {
        recognition.start();
      } catch (error) {
        recognitionError = true;
        setListening(false);
        showError("Voice recognition could not restart", error);
      }
    } else if (!responding) {
      setListening(false);
    }
  };
}

function toggleListening() {
  if (!recognition) return;
  recognitionError = false;
  if (listening) {
    listening = false;
    recognition.stop();
    setListening(false);
    return;
  }

  statusLine.textContent = "REQUESTING MICROPHONE ACCESS";
  systemState.textContent = "CONNECTING";
  try {
    recognition.start();
  } catch (error) {
    setListening(false);
    showError("Voice recognition could not start", error);
  }
}

async function processVoiceInput(text) {
  transcriptLine.textContent = `YOU  /  ${text}`;
  statusLine.textContent = "THINKING";
  systemState.textContent = "PROCESSING";
  answerLine.textContent = "Let me think that through…";
  responding = true;
  if (listening) recognition.stop();
  conversation.push({ role: "user", text });

  try {
    const response = await chrome.runtime.sendMessage({
      type: "voice-command",
      text,
      history: conversation.slice(-8)
    });
    if (!response || typeof response.text !== "string") {
      throw new Error("The assistant returned an invalid response.");
    }
    conversation.push({ role: "assistant", text: response.text });
    answerLine.textContent = response.text;
    statusLine.textContent = "AURA";
    systemState.textContent = listening ? "LISTENING" : "READY";
    speak(response.text);
  } catch (error) {
    responding = false;
    showError("I couldn't reach the assistant", error);
    restartListening();
  }
}

function speak(text) {
  if (!("speechSynthesis" in window)) {
    answerLine.textContent += " Speech playback is unavailable in this browser.";
    responding = false;
    restartListening();
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.96;
  utterance.pitch = 0.88;
  utterance.onend = () => {
    responding = false;
    restartListening();
  };
  utterance.onerror = (event) => {
    responding = false;
    systemState.textContent = "READY";
    statusLine.textContent = "SPEECH PLAYBACK UNAVAILABLE";
    answerLine.textContent += ` Speech playback failed: ${event.error}.`;
    restartListening();
  };
  window.speechSynthesis.speak(utterance);
}

function restartListening() {
  if (!listening || recognitionError) return;
  try {
    recognition.start();
  } catch (error) {
    recognitionError = true;
    setListening(false);
    showError("Voice recognition could not restart", error);
  }
}

function setListening(active) {
  listening = active;
  document.body.classList.toggle("is-listening", active);
  systemState.textContent = active ? "LISTENING" : "READY";
  if (active) statusLine.textContent = "LISTENING — TAP THE ORB TO STOP";
  else if (statusLine.textContent.startsWith("LISTENING")) statusLine.textContent = "AURA IS READY";
}

function showError(message, error) {
  console.error(message, error);
  systemState.textContent = "ACTION FAILED";
  statusLine.textContent = message.toUpperCase();
  answerLine.textContent = `${message}: ${error.message}`;
}
